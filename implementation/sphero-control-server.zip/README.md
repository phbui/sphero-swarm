To run the servers just double click run.bat.
